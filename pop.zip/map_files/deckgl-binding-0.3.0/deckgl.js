console.log("I scream for icecream!");

